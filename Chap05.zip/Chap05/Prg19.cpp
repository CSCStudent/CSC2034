/*************************************************************
 * It uses the idea of list multiplication to find the value *
 * of n! (factorial n)                                       *
 *************************************************************/
 
#include <iostream>
using namespace std; 
 
int main ( )
{
  // Variable declaration
  int n;
  unsigned long long factorial;

  // Input
  do 
  {
    cout << "Enter the factorial size: ";
    cin >> n;
  } while (n < 0);

  // initialization
  factorial = 1;
 
  // Processing
  for (int i = 1; i < n + 1; i++)
  {
    factorial *= i;
  }

  // Output
  cout << n << "! = " << factorial;
  return 0; 
 }



 
