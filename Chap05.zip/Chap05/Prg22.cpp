/*************************************************************
 * The program search a list of item to find if any item is  *
 * divisible by 7.                                           *
 *************************************************************/
 
#include <iostream>
using namespace std; 

int main ( )
{
  // Declaration
  bool success;
  int size;
  int item;

  // Input Validation
  do 
  {
    cout << "Enter the number of items in the list: ";
    cin >> size;
  } while (size < 0);

  // Processing
  for (int i = 0; (i < size ) && (!success); i++)
  {
    cout << "Enter the next item: ";
    cin >> item; 
    success = (item %7 == 0);
  }
  
  // Checking success or failure
  if (success)
  {
    cout << "The number " << item 
    cout <<  " is divisible by 7."  << endl;
  }
  else
  {
    cout << "None of the numbers is divisible by 7." << endl;
  }
  return 0;
}


