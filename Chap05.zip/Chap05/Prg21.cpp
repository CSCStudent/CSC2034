/**************************************************************
 * The program finds the smallest and the largest among a list*
 * of integers when the size of the list is known.            *
 **************************************************************/
 
#include <iostream>
#include <limits>  // Header file for numeric limits
using namespace std; 
 
int main ( )
{
  // Variable declaration
  int size;
  int number, smallest, largest;

  // Initialization
  smallest = numeric_limits <int> :: max();
  largest = numeric_limits <int> :: min();

  // Size Input
  do
  {
    cout << "Enter the size of the list (non-negative): ";
    cin >> size;
  } while (size <= 0);

  // Processing 
  for (int i = 1; i <= size; i++)
  {
    cout << "Enter the next item: "; 
    cin >> number;
    if (number < smallest)
    {
      smallest = number;
    } 
    if (number > largest)
    {
      largest = number;
    } 
  }
 
  // Result output
  cout << "The smallest item is: " << smallest << endl;
  cout << "The largest item is: " << largest << endl;
  return 0;
} 


