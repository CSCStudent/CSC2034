/**************************************************************
 * Use of the counter-controlled while loop to find  average  *
 * of scores for each student.                                *
 **************************************************************/
 
#include <iostream>
#include <iomanip>
using namespace std;

int main ()	
{
  // Declaration
  int score;
  int sum = 0;
  double average;
 
  // Loop
  int counter = 0;  // initialize the counter
  while (counter < 4)   // Test the counter
  {
    // Process (Read and add score to the sum)
    cout << "Enter the next score (between 0 and 100): ";
    cin >> score;
    sum = sum + score;
    counter++;   // Increment the counter
  }
 
  // Result	
  average = static_cast <double> (sum) / 4;
  cout << fixed << setprecision (2) << showpoint;
  cout << "The average of scores is: " << average;
  return 0; 
}


