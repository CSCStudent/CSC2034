/*************************************************************
 * It uses the idea of multiplication to find the value of a *
 * base to the power of an exponent (b^n).                   *
 *************************************************************/
 
#include <iostream>
using namespace std; 
 
int main ( )
{
  // Variable declaration
  int base, exponent;
  unsigned long int power, temp;
  bool overflow;

  // input validation for base 
  do
  {
    cout << "Enter a non-negative integer value for b: " ;
    cin >> base;
  } while (base < 0);

  // input validation for exponent	
  do
  {
    cout << "Enter a non-negative integer value for n: " ;
    cin >> exponent;
  } while (exponent < 0);

  // initialization
  power = 1; 
  temp = power;
  overflow = false;

  // Processing
  for (int i = 1; (i <= exponent) && (!overflow); i++)
  {
    power *= base;
    if (power / base  != temp)
    {
      overflow = true; // terminate the loop
    } 
    temp = power;
  }
 
  // Output
  if (overflow)
  {
    cout << "Overflow occurred! Try again." ;
  } 
  else
  {
    cout << base << "^" << exponent << " = " << power;
  }
  return 0;
}


 