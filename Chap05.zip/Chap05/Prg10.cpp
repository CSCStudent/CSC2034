/*************************************************************
 * Prints numbers divisible by 7 in the range 1 to 300 in a  *
 * table made of 10 columns.                                 *
 *************************************************************/
 
#include <iostream>
#include <iomanip>
using namespace std;

int main ()	
{
  // Declaration including initialization
  int lower = 1;
  int higher = 300;
  int divisor = 7;
  int col = 1;

  // Processing loop		
  for (int i = lower; i < higher ; i++)
  {	    
    if (i % divisor == 0)
    {
      cout << setw(4) << i;
      col++;
      if (col > 10 )
      {
        cout << endl;
        col = 1;
      }
    }
  } 
  return 0; 
} 


