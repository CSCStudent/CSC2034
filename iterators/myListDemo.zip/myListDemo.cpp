#include <iostream>
#include <string>
#include "myList.h"

using namespace std;

int main(int argc, char *argv[]) {
	myList<string> ml;
	myList<string>::iterator itr;

	ml.insert("January");
	ml.insert("February");
	ml.insert("March");

	for (itr = ml.begin(); itr != ml.end(); itr++)
		cout << *itr << endl;

	return 0;
}