// FILE: myList5.h (part of the namespace main_savitch_chapter6)
// TEMPLATE CLASS PROVIDED:
//   myList<T> (a collection of Ts; each T may appear multiple times)
//
// TYPEDEFS for the myList<T> template class:
//     This is the T type from the template parameter.
//     It is the data type of the Ts in the myList. It may be any 
//     of the C++ built-in types (int, char, etc.), or a class with a default
//     constructor, a copy constructor, an assignment
//     operator, and a test for equality (x == y).
//
//   myList<T>::size_type
//     This is the data type of any variable that keeps track of how many Ts
//     are in a myList
//
//   myList<T>::iterator
//     Forward iterators for a myList or a const myList.
//   
// CONSTRUCTOR for the myList<T> class:
//   myList( )
//     Postcondition: The myList is empty.
//
// MODIFICATION MEMBER FUNCTIONS for the myList<T> class:
//   size_type erase(const T& target)
//     Postcondition: All copies of target have been removed from the myList.
//     The return value is the number of copies removed (which could be zero).
//
//   bool erase_one(const T& target)
//     Postcondition: If target was in the myList, then one copy of target has
//     been removed from the myList; otherwise the myList is unchanged. A true
//     return value indicates that one copy was removed; false indicates that
//     nothing was removed.
//
//   void insert(const T& entry) 
//     Postcondition: A new copy of entry has been inserted into the myList.
//
//   void operator +=(const myList& addend) 
//     Postcondition: Each T in addend has been added to this myList.
//
// CONSTANT MEMBER FUNCTIONS for the myList<T> class:
//   size_type count(const T& target) const 
//     Postcondition: Return value is number of times target is in the myList.
//
//   T grab( ) const 
//     Precondition: size( ) > 0.
//     Postcondition: The return value is a randomly selected T from the myList.
//
//   size_type size( ) const 
//     Postcondition: Return value is the total number of Ts in the myList.
//
// STANDARD ITERATOR MEMBER FUNCTIONS (provide a forward iterator):
//   iterator begin( )
//   const_iterator begin( ) const
//   iterator end( )
//   const iterator end( ) const
//
// NONMEMBER FUNCTIONS for the myList<T> class:
//   template <class T>
//   myList<T> operator +(const myList<T>& b1, const myList<T>& b2) 
//     Postcondition: The myList returned is the union of b1 and b2.
//
// VALUE SEMANTICS for the myList<T> class:
//    Assignments and the copy constructor may be used with myList objects.
//
// DYNAMIC MEMORY USAGE by the myList<T>: 
//   If there is insufficient dynamic memory, then the following functions throw
//   bad_alloc: The constructors, insert, operator +=, operator +, and the
//   assignment operator.

#ifndef MAIN_SAVITCH_myList5_H
#define MAIN_SAVITCH_myList5_H
#include <cstdlib>   // Provides NULL and size_t and NULL
#include "node.h"   // Provides node class

    template <class T>
    class myList
    {
    public:
        // TYPEDEFS
        typedef std::size_t size_type;
        typedef node_iterator<T> iterator;

        // CONSTRUCTORS and DESTRUCTOR
        myList();
        myList(const myList<T>& source);
        ~myList();

        // MODIFICATION MEMBER FUNCTIONS
        size_type erase(const T& target);
        bool erase_one(const T& target);
        void insert(const T& entry);
        void operator +=(const myList& addend);
        void operator =(const myList& source);

        // CONST MEMBER FUNCTIONS
        size_type count(const T& target) const;
        T grab() const;
        size_type size() const { return many_nodes; }

        // FUNCTIONS TO PROVIDE ITERATORS
        node_iterator<T> begin()
        {
            return node_iterator<T>(head_ptr);
        }
        node_iterator<T> end()
        {
            return node_iterator<T>();
        } 
        
    private:
        node<T>* head_ptr;        // Head pointer for the list of Ts
        size_type many_nodes;        // Number of nodes on the list
    };

    // NONMEMBER functions for the myList
    template <class T>
    myList<T> operator +(const myList<T>& b1, const myList<T>& b2);

// The implementation of a template class must be included in its header file:
// FILE: myList5.template
// CLASS implemented: myList (see myList5.h for documentation)
// NOTE:
//   Since myList is a template class, this file is included in node2.h.
// INVARIANT for the myList class:
//   1. The Ts in the myList are stored on a linked list;
//   2. The head pointer of the list is stored in the member variable head_ptr;
//   3. The total number of Ts in the list is stored in the member variable
//       many_nodes.

#include <cassert>  // Provides assert
#include <cstdlib>  // Provides NULL, rand
#include "node.h"  // Provides node 

        template <class T>
        myList<T>::myList()
            // Library facilities used: cstdlib
        {
            head_ptr = NULL;
            many_nodes = 0;
        }

        template <class T>
        myList<T>::myList(const myList<T>& source)
            // Library facilities used: node2.h
        {
            node<T>* tail_ptr;  // Needed for argument of list_copy

            list_copy(source.head_ptr, head_ptr, tail_ptr);
            many_nodes = source.many_nodes;
        }

        template <class T>
        myList<T>::~myList()
            // Library facilities used: node2.h
        {
            list_clear(head_ptr);
            many_nodes = 0;
        }

        template <class T>
        typename myList<T>::size_type myList<T>::count(const T& target) const
            // Library facilities used: cstdlib, node.h
        {
            size_type answer;
            const node<T>* cursor;

            answer = 0;
            cursor = list_search(head_ptr, target);
            while (cursor != NULL)
            {
                // Each time that cursor is not NULL, we have another occurrence of
                // target, so we add one to answer, and move cursor to the next
                // occurrence of the target.
                ++answer;
                cursor = cursor->link();
                cursor = list_search(cursor, target);
            }
            return answer;
        }

        template <class T>
        typename myList<T>::size_type myList<T>::erase(const T& target)
            // Library facilities used: cstdlib, node2.h
        {
            size_type answer = 0;
            node<T>* target_ptr;

            target_ptr = list_search(head_ptr, target);
            while (target_ptr != NULL)
            {
                // Each time that target_ptr is not NULL, we have another occurrence
            // of target. We remove this target using the same technique that
            // was used in erase_one.
                ++answer;
                --many_nodes;
                target_ptr->set_data(head_ptr->data());
                target_ptr = target_ptr->link();
                target_ptr = list_search(target_ptr, target);
                list_head_remove(head_ptr);
            }
            return answer;
        }

        template <class T>
        bool myList<T>::erase_one(const T& target)
            // Library facilities used: cstdlib, node2.h
        {
            node<T>* target_ptr;

            target_ptr = list_search(head_ptr, target);
            if (target_ptr == NULL)
                return false; // target isn't in the myList, so no work to do
            target_ptr->set_data(head_ptr->data());
            list_head_remove(head_ptr);
            --many_nodes;
            return true;
        }

        template <class T>
        T myList<T>::grab() const
            // Library facilities used: cassert, cstdlib, node2.h
        {
            size_type i;
            const node<T>* cursor;

            assert(size() > 0);
            i = (std::rand() % size()) + 1;
            cursor = list_locate(head_ptr, i);
            return cursor->data();
        }

        template <class T>
        void myList<T>::insert(const T& entry)
            // Library facilities used: node.h
        {
            list_head_insert(head_ptr, entry);
            ++many_nodes;
        }

        template <class T>
        void myList<T>::operator +=(const myList<T>& addend)
            // Library facilities used: node.h
        {
            node<T>* copy_head_ptr;
            node<T>* copy_tail_ptr;

            if (addend.many_nodes > 0)
            {
                list_copy(addend.head_ptr, copy_head_ptr, copy_tail_ptr);
                copy_tail_ptr->set_link(head_ptr);
                head_ptr = copy_head_ptr;
                many_nodes += addend.many_nodes;
            }
        }

        template <class T>
        void myList<T>::operator =(const myList<T>& source)
            // Library facilities used: node.h
        {
            node<T>* tail_ptr; // Needed for argument to list_copy

            if (this == &source)
                return;

            list_clear(head_ptr);
            many_nodes = 0;

            list_copy(source.head_ptr, head_ptr, tail_ptr);
            many_nodes = source.many_nodes;
        }

        template <class T>
        myList<T> operator +(const myList<T>& b1, const myList<T>& b2)
        {
            myList<T> answer;

            answer += b1;
            answer += b2;
            return answer;
        }

#endif


