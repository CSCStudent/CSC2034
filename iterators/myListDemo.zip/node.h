// FILE: node.h (part of the namespace main_savitch_6B)
// PROVIDES: A template class for a node in a linked list, and list manipulation
// functions. The template parameter is the type of the data in each node.
// This file also defines a template class: node_iterator<T>.
// The node_iterator is a forward iterators with two constructors:
// (1) A constructor (with a node<T>* parameter) that attaches the iterator
// to the specified node in a linked list, and (2) a default constructor that
// creates a special iterator that marks the position that is beyond the end of a
// linked list. There is also a const_node_iterator for use with
// const node<T>* .
//
// TYPEDEF for the node<T> template class:
//   Each node of the list contains a piece of data and a pointer to the
//   next node. The type of the data (node<T>::value_type) is the T type
//   from the template parameter. The type may be any of the built-in C++ classes
//   (int, char, ...) or a class with a default constructor, an assignment
//   operator, and a test for equality (x == y).
// NOTE:
//   Many compilers require the use of the new keyword typename before using
//   the expression node<T>::value_type. Otherwise
//   the compiler doesn't have enough information to realize that it is the
//   name of a data type.
//
// CONSTRUCTOR for the node<T> class:
//   node(
//     const T& init_data = T(),
//     node* init_link = NULL
//   )
//     Postcondition: The node contains the specified data and link.
//     NOTE: The default value for the init_data is obtained from the default
//     constructor of the T. In the ANSI/ISO standard, this notation
//     is also allowed for the built-in types, providing a default value of
//     zero. The init_link has a default value of NULL.
//
// NOTE about two versions of some functions:
//   The data function returns a reference to the data field of a node and
//   the link function returns a copy of the link field of a node.
//   Each of these functions comes in two versions: a const version and a
//   non-const version. If the function is activated by a const node, then the
//   compiler choses the const version (and the return value is const).
//   If the function is activated by a non-const node, then the compiler choses
//   the non-const version (and the return value will be non-const).
// EXAMPLES:
//    const node<int> *c;
//    c->link( ) activates the const version of link returning const node*
//    c->data( ) activates the const version of data returning const T&
//    c->data( ) = 42; ... is forbidden
//    node<int> *p;
//    p->link( ) activates the non-const version of link returning node*
//    p->data( ) activates the non-const version of data returning T&
//    p->data( ) = 42; ... actually changes the data in p's node
//
// MEMBER FUNCTIONS for the node<T> class:
//   const T& data( ) const <----- const version
//   and
//   T& data( ) <----------------- non-const version
//   See the note (above) about the const version and non-const versions:
//     Postcondition: The return value is a reference to the  data from this node.
//
//   const node* link( ) const <----- const version
//   and
//   node* link( ) <----------------- non-const version
//   See the note (above) about the const version and non-const versions:
//     Postcondition: The return value is the link from this node.
//   
//   void set_data(const T& new_data)
//     Postcondition: The node now contains the specified new data.
//   
//   void set_link(node* new_link)
//     Postcondition: The node now contains the specified new link.
//
// FUNCTIONS in the linked list toolkit:
//   template <typename T>
//   void list_clear(node<T>*& head_ptr) 
//     Precondition: head_ptr is the head pointer of a linked list.
//     Postcondition: All nodes of the list have been returned to the heap,
//     and the head_ptr is now NULL.
//
//   template <typename T>
//   void list_copy
//   (const node<T>* source_ptr, node<T>*& head_ptr, node<T>*& tail_ptr)
//     Precondition: source_ptr is the head pointer of a linked list.
//     Postcondition: head_ptr and tail_ptr are the head and tail pointers for
//     a new list that contains the same Ts as the list pointed to by
//     source_ptr. The original list is unaltered.
//
//   template <typename T>
//   void list_head_insert(node<T>*& head_ptr, const T& entry) 
//     Precondition: head_ptr is the head pointer of a linked list.
//     Postcondition: A new node containing the given entry has been added at
//     the head of the linked list; head_ptr now points to the head of the new,
//     longer linked list.
//
//   template <typename T>
//   void list_head_remove(node<T>*& head_ptr) 
//     Precondition: head_ptr is the head pointer of a linked list, with at
//     least one node.
//     Postcondition: The head node has been removed and returned to the heap;
//     head_ptr is now the head pointer of the new, shorter linked list.
//
//   template <typename T>
//   void list_insert(node<T>* previous_ptr, const T& entry) 
//     Precondition: previous_ptr points to a node in a linked list.
//     Postcondition: A new node containing the given entry has been added
//     after the node that previous_ptr points to.
//
//   template <typename T>
//   size_t list_length(const node<T>* head_ptr)
//     Precondition: head_ptr is the head pointer of a linked list.
//     Postcondition: The value returned is the number of nodes in the linked
//     list.
//
//   template <typename NodePtr, class SizeType>
//   NodePtr list_locate(NodePtr head_ptr, SizeType position)
//   The NodePtr may be either node<T>* or const node<T>*
//     Precondition: head_ptr is the head pointer of a linked list, and
//     position > 0.
//     Postcondition: The return value is a pointer that points to the node at
//     the specified position in the list. (The head node is position 1, the
//     next node is position 2, and so on). If there is no such position, then
//     the null pointer is returned.
//
//   template <typename T>
//   void list_remove(node<T>* previous_ptr) 
//     Precondition: previous_ptr points to a node in a linked list, and this
//     is not the tail node of the list.
//     Postcondition: The node after previous_ptr has been removed from the
//     linked list.
//
//   template <typename NodePtr, class T>
//   NodePtr list_search
//   (NodePtr head_ptr, const T& target) 
//   The NodePtr may be either node<T>* or const node<T>*
//     Precondition: head_ptr is the head pointer of a linked list.
//     Postcondition: The return value is a pointer that points to the first
//     node containing the specified target in its data member. If there is no
//     such node, the null pointer is returned.
//
// DYNAMIC MEMORY usage by the toolkit: 
//   If there is insufficient dynamic memory, then the following functions throw
//   bad_alloc: the constructor, list_head_insert, list_insert, list_copy.

#ifndef MAIN_SAVITCH_NODE2_H  
#define MAIN_SAVITCH_NODE2_H
#include <cassert>    // Provides assert
#include <cstdlib>   // Provides NULL and size_t
#include <iterator>  // Provides iterator and forward_iterator_tag

    template <typename T>
    class node
    {
    public:
        // TYPEDEF
//        typedef T value_type;
// 
        // CONSTRUCTOR
        node(const T& init_data = T(), node* init_link = NULL)
        {
            data_field = init_data; link_field = init_link;
        }
        // MODIFICATION MEMBER FUNCTIONS
        T& data() { return data_field; }
        node* link() { return link_field; }
        void set_data(const T& new_data) { data_field = new_data; }
        void set_link(node* new_link) { link_field = new_link; }
        // CONST MEMBER FUNCTIONS
        const T& data() const { return data_field; }
        const node* link() const { return link_field; }
    private:
        T data_field;
        node* link_field;
    };

    // FUNCTIONS to manipulate a linked list:
    template <typename T>
    void list_clear(node<T>*& head_ptr);

    template <typename T>
    void list_copy
    (const node<T>* source_ptr, node<T>*& head_ptr, node<T>*& tail_ptr);

    template <typename T>
    void list_head_insert(node<T>*& head_ptr, const T& entry);

    template <typename T>
    void list_head_remove(node<T>*& head_ptr);

    template <typename T>
    void list_insert(node<T>* previous_ptr, const T& entry);

    template <typename T>
    std::size_t list_length(const node<T>* head_ptr);

    template <typename NodePtr, class SizeType>
    NodePtr list_locate(NodePtr head_ptr, SizeType position);

    template <typename T>
    void list_remove(node<T>* previous_ptr);

    template <typename NodePtr, class T>
    NodePtr list_search(NodePtr head_ptr, const T& target);

    // FORWARD ITERATORS to step through the nodes of a linked list
    // A node_iterator of can change the underlying linked list through the
    // * operator, so it may not be used with a const node. The
    // node_const_iterator cannot change the underlying linked list
    // through the * operator, so it may be used with a const node.
    // WARNING:
    // This classes use std::iterator as its base class;
    // Older compilers that do not support the std::iterator class can
    // delete everything after the word iterator in the second line:

    template <typename T>
    class node_iterator
        : public std::iterator<std::forward_iterator_tag, T>
    {
    public:
        node_iterator(node<T>* initial = NULL)
        {
            current = initial;
        }
        T& operator *() const
        {
            return current->data();
        }
        node_iterator& operator ++() // Prefix ++
        {
            current = current->link();
            return *this;
        }
        node_iterator operator ++(int) // Postfix ++
        {
            node_iterator original(current);
            current = current->link();
            return original;
        }
        bool operator ==(const node_iterator other) const
        {
            return current == other.current;
        }
        bool operator !=(const node_iterator other) const
        {
            return current != other.current;
        }
    private:
        node<T>* current;
    };

    // IMPLEMENTS: The functions of the node template class and the
    // linked list toolkit (see node2.h for documentation).
    //
    // NOTE:
    //   Since node is a template class, this file is included in node2.h.
    //   Therefore, we should not put any using directives in this file.
    //
    // INVARIANT for the node class:
    //   The data of a node is stored in data_field, and the link in link_field.

    
        template <typename T>
        void list_clear(node<T>*& head_ptr)
            // Library facilities used: cstdlib
        {
            while (head_ptr != NULL)
                list_head_remove(head_ptr);
        }

        template <typename T>
        void list_copy(
            const node<T>* source_ptr,
            node<T>*& head_ptr,
            node<T>*& tail_ptr
        )
            // Library facilities used: cstdlib
        {
            head_ptr = NULL;
            tail_ptr = NULL;

            // Handle the case of the empty list
            if (source_ptr == NULL)
                return;

            // Make the head node for the newly created list, and put data in it
            list_head_insert(head_ptr, source_ptr->data());
            tail_ptr = head_ptr;

            // Copy rest of the nodes one at a time, adding at the tail of new list
            source_ptr = source_ptr->link();
            while (source_ptr != NULL)
            {
                list_insert(tail_ptr, source_ptr->data());
                tail_ptr = tail_ptr->link();
                source_ptr = source_ptr->link();
            }
        }

        template <typename T>
        void list_head_insert(node<T>*& head_ptr, const T& entry)
        {
            head_ptr = new node<T>(entry, head_ptr);
        }

        template <typename T>
        void list_head_remove(node<T>*& head_ptr)
        {
            node<T>* remove_ptr;

            remove_ptr = head_ptr;
            head_ptr = head_ptr->link();
            delete remove_ptr;
        }

        template <typename T>
        void list_insert(node<T>* previous_ptr, const T& entry)
        {
            node<T>* insert_ptr;

            insert_ptr = new node<T>(entry, previous_ptr->link());
            previous_ptr->set_link(insert_ptr);
        }

        template <typename T>
        std::size_t list_length(const node<T>* head_ptr)
            // Library facilities used: cstdlib
        {
            const node<T>* cursor;
            std::size_t answer;

            answer = 0;
            for (cursor = head_ptr; cursor != NULL; cursor = cursor->link())
                ++answer;

            return answer;
        }

        template <typename NodePtr, class SizeType>
        NodePtr list_locate(NodePtr head_ptr, SizeType position)
            // Library facilities used: cassert, cstdlib
        {
            NodePtr cursor;
            SizeType i;

            assert(0 < position);
            cursor = head_ptr;
            for (i = 1; (i < position) && (cursor != NULL); ++i)
                cursor = cursor->link();
            return cursor;
        }

        template <typename T>
        void list_remove(node<T>* previous_ptr)
        {
            node<T>* remove_ptr;

            remove_ptr = previous_ptr->link();
            previous_ptr->set_link(remove_ptr->link());
            delete remove_ptr;
        }

        template <typename NodePtr, class T>
        NodePtr list_search(NodePtr head_ptr, const T& target)
            // Library facilities used: cstdlib
        {
            NodePtr cursor;

            for (cursor = head_ptr; cursor != NULL; cursor = cursor->link())
                if (target == cursor->data())
                    return cursor;
            return NULL;
        }

#endif

