/**************************************************************
 * Use of an if-else statement to find a pass/no-pass grade   *
 **************************************************************/
 
#include <iostream>
using namespace std;

int main ()	
{
  // Local Declaration
  int score;

  // Input
  cout << "Enter a score between 0 and 100: ";
  cin >> score;

  // Decision
  if (score  >= 70)
  {
    cout << "Grade is pass" << endl;
  } // End if
  else 
  {
   cout << "Grade is nopass" << endl;
  } //End else
  return 0;	
}

 