/**************************************************************
 * Use of if-statement to find gross payment of an employee   *
 **************************************************************/

#include <iostream>
#include <iomanip>;
using namespace std;

int main ()	
{
  // Declaration;
  double hours;
  double rate;
  double regularPay;
  double overPay;
  double totalPay;

  // Input
  cout << "Enter hours worked: ";
  cin >> hours;	
  cout << "Enter pay rate: ";
  cin >> rate;

  // Calculation that does not depend on decision 
  regularPay = hours * rate;
  overPay = 0.0;

  // Calculation that is skipped if hours worked 
  // is not more than 40
  if (hours > 40.0)	
  {
    overPay = (hours - 40.0) * rate * 0.30;	
  }
 	
  // Rest of the calculation
  totalPay = regularPay + overPay; 
  
  // Printing output
  cout << fixed << showpoint;  
  cout << "Regular pay  = " << setprecision (2);
  cout << regularPay   << endl;
  cout << "Over time pay = " << setprecision (2) 
  cout <<  overPay << endl;
  cout << "Total pay = " << setprecision (2) 
  cout << totalPay << endl;	
  return 0;
}


