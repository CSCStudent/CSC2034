/*************************************************************
 * Use of if-else statement to print larger between two      * 
 * numbers or print the first if numbers are equal           *
 *************************************************************/ 

#include <iostream>
using namespace std;

int main ()	
{
  // Declaration
  int num1, num2;
  int larger;

  // Input Stataments
  cout << "Enter the first number: ";
  cin >> num1;
  cout << "Enter the second number: ";
  cin >> num2;

  // Decision	
  if (num1 >=  num2)
  {
    larger = num1;
  } // End if
  else 
  {
    larger = num2;
  } // End else

  // Printing result
  cout << "The larger number is: " << larger;
  return 0;
}

