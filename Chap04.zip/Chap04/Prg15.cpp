/**************************************************************
 * Finding the student score based on the given three scores  *
 * The program sets the student score to average of maximum   *
 * and minimum of the three scores                            *
 **************************************************************/ 

#include <iostream>
using namespace std;

int main ( )
{
  // Declarations
  int score1, score2, score3, maxScore, minScore, score;

  // Input	
  cout << "Enter the first score: ";
  cin >> score1;
  cout << "Enter the second score: ";
  cin >> score2;
  cout << "Enter the third score: ";
  cin >> score3;

  // Find maximum score	
  if (score1 > score2 && score1 > score3)
  {
    maxScore = score1;
  }
  else if (score2 > score1 && score2 > score3)
  {
    maxScore = score2;
  }
  else
  {
    maxScore = score3;
  }

  // Find minimum score	
  if (score1 < score2 && score1 < score3)
  {
    minScore = score1;
  }
  else if (score2 < score1 && score2 <= score3)
  {
    minScore = score2;
  }
  else
  {
    minScore = score3;
  }

  // Find and round the student score	
  int temp = maxScore + minScore;
  if (temp % 2 == 1) 
  {
    temp += 1;
  }
  score = temp / 2;
 
  // Print results	
  cout << "Scores: " << score1 << " " << score2 << " " << 
  cout << score3 << endl;
  cout << "minimum and maximum scores: ";
  cout << minScore << " " << maxScore << endl;
  cout << "Student score: " << score;
  return 0;      
} 



