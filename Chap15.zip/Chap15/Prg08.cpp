/**************************************************************
 * The application file to test a function template           *
 **************************************************************/

#include "smaller.h"

int main ( )
{
  cout << "Smaller of �a� and �B�: "; 
  cout << smaller ('a', 'B') << endl;

  cout << "Smaller of 12 and 15: "; 
  cout << smaller (12, 15) << endl;

  cout << "Smaller of 44.2 and 33.1: ";
  cout << smaller (44.2, 33.1) << endl; 

  return 0;
}


	