/**************************************************************
 * The application file to test the Person class              *
 **************************************************************/

#include "person.h"

int main ( )
{
  // Instantiation
  Date date1  (5, 6, 1980);
  Person person1 (111111456, &date1);
  
  // Output 	
  person1.print ( );

  date1.setMonth(3);
  person1.print();

  return 0;
}

	