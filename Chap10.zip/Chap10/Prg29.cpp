/**************************************************************
 *A program to change a Roman string to its equivalent decimal*
 **************************************************************/

#include "customized.h"
#include <string>
#include <iostream>
using namespace std;

/**************************************************************
 * A function to change a Roman character to its value.       *
 **************************************************************/

int findValue (char ch)
{
  if (ch == 'M') return 1000;
  if (ch == 'D') return 500;
  if (ch == 'C') return 100;
  if (ch == 'L') return 50;
  if (ch == 'X') return 10;
  if (ch == 'V') return 5;
  if (ch == 'I') return 1;
}

int main ( )
{
  // Declaration and Initialization
  string roman; 
  int pre = 0;
  int cur = 0;;
  int decimal = 0;

  // Input of Roman string and validation
  do 
  {
    cout << "Enter a valid Roman string: ";
    cin >> roman;
  } while(roman.find_first_not_of ("IVXLCDM") < roman.size ( ));

  // Transformation to decimal	
  while (!roman.empty ( ))
  {
    pre = cur;
    char ch = popFront (roman);
    cur = findValue (ch);
    decimal += cur;
    if (cur > pre)
    {
      decimal -= 2 * pre;
    }
  }

  // Second validation		
  if (decimal > 3888)
  {
    cout << "Invalid literal. The program quits";
    return 0;
  }

  // Printing the decimal value
  cout << "The decimal number is: " << decimal;
  return 0;
}

 	