/**************************************************************
 *A program to change a decimal number to its equivalent Roman*
 *numeral.                                                    *
 **************************************************************/

#include <string>
#include <iostream>
using namespace std;

/**************************************************************
 * A function that converts the number of thousands, hundreds,*
 * tens or ones to a substring and append it to the previously*
 * made Roman numeral.                                        *
 **************************************************************/

void convert (string& strg, int n, char c1, char c2, char c3)
{
  string temp;
  if (n == 9)
  {
    temp.append (1, c3);
    temp.append (1, c1);
  }
  else if (n >= 5)
  {
    temp.append(1, c2);
    temp.append (n - 5 , c3);
  }
  else if (n == 4)
  {
    temp.append (1, c3);
    temp.append (1, c2);
  }
  else 
  {
    temp.append(n, c3);
  }
  strg.append (temp);
}



int main ( )
{
  // Declarations 
  int decimal;
  int n; 
  string roman;

  // Input decimal and validate
  do 
  {
    cout << "Enter decimal number: ";
    cin >> decimal;
  } while (decimal < 0 || decimal > 3888);

  // Find the substring for thousands
  n = decimal / 1000;
  convert (roman, n, '\0', '\0', 'M');
  decimal  = decimal % 1000;

  // Find the substring for hundreds
  n = decimal / 100;
  convert (roman, n, 'M', 'D', 'C');
  decimal  = decimal % 100;

  // Find the substring for tens
  n = decimal / 10;
  convert (roman, n, 'C', 'L', 'X');
  decimal  = decimal % 10;

  // Find the substring for ones
  n = decimal;
  convert (roman, n, 'X', 'V', 'I');

  // Print the Roman numeral
  cout << "Roman numeral: "  << roman; 
  return 0;
}

 	