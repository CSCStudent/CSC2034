// castingDemo.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// C++ program to demonstrate
// explicit type casting

#include <iostream>
using namespace std;

int main1()
{
	double x = 1.2;

	// Explicit conversion from double to int
	int sum = (int)x + 1;

	cout << "Sum = " << sum;

	// to demonstrate static_cast

	float f = 3.5;

	// Implicit type case
	// float to int
	int a = f;
	cout << "The Value of a: " << a;

	// using static_cast for float to int
	int b = static_cast<int>(f);
	cout << "\nThe Value of b: " << b;
	
	return 0;
}


