/*
// C++ Program demonstrates successful
// dynamic casting and it returns a
// value of type new_type
// for dynamic casting there must be one Virtual function.Suppose 
// If we do not use the virtual function, then it generates an error message 
// Source type is not polymorphic�.
*/
#include <iostream>
#include <string>

using namespace std;
// Base Class declaration
class Base {
public:
	virtual void print()
	{
		cout << "Base" << endl;
	}
};

// Derived1 class declaration
class Derived1 : public Base {
public:
	void print()
	{
		cout << "Derived1" << endl;
	}
};

// Derived2 class declaration
class Derived2 : public Base {
public:
	void print()
	{
		cout << "Derived2" << endl;
	}
};

// Driver Code
int main()
{
	Derived1 d1;

	// Base class pointer holding
	// Derived1 Class object

	// Dynamic_casting -- upcast
	Base* bp = dynamic_cast<Base*>(&d1);

	// Dynamic_casting -- downcast
	Derived1* dp2 = dynamic_cast<Derived1*>(bp);

	cout << "bp type: " << typeid(bp).name() << endl;
	cout << "d1 type: " << typeid(d1).name() << endl;

	// If the cast fails and new_type is a pointer type, it returns a null pointer 
	if (dp2 == nullptr) {
		cout << "null" << endl;
		return 1;
	}
	else
		cout << "not null" << endl;

	bp->print();
	d1.print();
	return 0;
}
