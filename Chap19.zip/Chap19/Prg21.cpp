/*************************************************************
 * Using functions that call another function                *
 *************************************************************/

#include <iostream>
using namespace std;

// Definition of print function
void print (int value) 
{
  cout << value << endl;
}


// Definition of fun function
void fun (int x, void(*f)(int))
{
  f(x);
}



int main()
{
  fun(24, print);  // Calling function fun
  fun(88, print);  // Calling function fun
  return 0;
}

