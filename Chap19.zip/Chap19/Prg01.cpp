/*************************************************************
 * A simple program to test regular and reverse navigation   *
 *************************************************************/

#include <vector>
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  // Constructing a vector of 10 elements and two iterators
  vector <int> vec(10);
  vector <int> :: iterator iter;
  vector <int> :: reverse_iterator rIter;

  // Changing the value of elements
  for (int i = 0; i < 10; i++)
  {
    vec.at(i) = i * i; 
  }


  // Printing the elements using the forward iterator
  cout << "Regular navigation: ";
  for (iter = vec.begin() ; iter != vec.end() ; ++iter)
  {
    cout << setw(4) << *iter;
  }
  cout << endl;
 

  // Printing the elements using reverse iterator
  cout << "Reverse navigation: ";
  for (rIter = vec.rbegin() ; rIter != vec.rend() ; ++rIter)
  {
    cout << setw(4) << *rIter;
  }
  cout <<  endl;

  return 0;
}


	