/*************************************************************
 * A program to use a pointer to function and a functor      *
 *************************************************************/

#include <vector>
#include <algorithm>
#include <iostream>
#include <functional>
using namespace std;


// User-defined print function
void print(int value) 
{
  cout << value << " ";
}

int main()
{
  // Creation of a vector with four nodes
  vector <int> vec;
  vec.push_back(24);
  vec.push_back(42);
  vec.push_back(73);
  vec.push_back(92);


  // Printing the node using a pointer to user-defined function	
  for_each(vec.begin(), vec.end(), print);
  cout << endl;

  // Negating the values of all nodes and print them again
  transform(vec.begin(), vec.end(), vec.begin(), 
            negate <int>()());
  for_each(vec.begin(), vec.end(), print);

  return 0;
}



