/*************************************************************
 * A program to simulate a table using a vector of vectors   *
 *************************************************************/

#include <vector>
#include <iostream>
#include <iomanip>
using namespace std;


int main()
{
  // Creation of a vector of vectors
  int rows = 10;
  int cols = 10;
  vector < vector <int> > table(rows, vector <int>(cols));


  // Changing values from default
  for (int i = 0; i < rows ; i++)
  {
    for (int j = 0 ; j < cols; j++) 
    {
      table [i][j] = (i + 1) * (j + 1);
    }
  }


  // Retrieving and printing values	
  for (int i = 0; i < rows ; i++)
  {
    for (int j = 0 ; j < cols; j++) 
    {
      cout << setw(4) << table [i][j] << " ";
    }
   cout << endl;
  }

  return 0;
}	



