/**************************************************************
 * The program that creates a list of five integers and print *
 * in both forward and reverse direction                      *
 **************************************************************/


#include <list>
#include <iostream>
using namespace std;

int main()
{
  // Instantiation of a list and declaration of a variable
  list <int> lst;
  int value;


  // Inputting five integers and store then in the list	
  for (int i = 0; i < 5; i++)
  {
    cout << "Enter an integer: ";
    cin >> value;
    lst.push_back(value);
  }


  // Printing the list in forward direction	
  cout << "Print the list in forward direction. " << endl;
  list <int> :: iterator iter1;
  for(iter1 = lst.begin(); iter1 != lst.end(); iter1++)
  {
    cout << *iter1 << "  " ;
  }
  cout << endl;


  // Printing the list in backward direction	
  cout << "Print the list in reverse direction. " << endl;
  list <int> :: reverse_iterator iter2;
  for (iter2 = lst.rbegin(); iter2 != lst.rend(); iter2++)
  {
    cout << *iter2 << "  " ;
  }

  return 0;
} 



