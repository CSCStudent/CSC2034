/**************************************************************
 * Rewrite of Program 19-2 using list instead of vector       *
 **************************************************************/

#include <iostream>
#include <list>
using namespace std;

int main()
{
  // Instantiation of list container and defining two iterators
  list <int> lst;
  list <int> :: iterator iter1; 
  list <int> :: reverse_iterator iter2; 


  // Inserting 10 integers into the list	
  for (int i = 0; i < 10; i++)
  {
    lst.push_back(i * 10);
  }

 
  // Moving forward and backward using iter1	
  cout << "Printing 40 followed by 20" << endl;
  iter1 = lst.begin();
  iter1++;
  iter1++;
  iter1++;
  iter1++;
  cout << *iter1 << " ";
  iter1--;
  iter1--;
  cout << *iter1 << endl;


  // Moving forward and backward using iter2
  cout << "Printing 50 followed by 70" << endl;
  iter2 = lst.rbegin();
  iter2++;
  iter2++;
  iter2++;
  iter2++;
  cout << *iter2 << " ";
  iter2--;
  iter2--;
  cout << *iter2 << endl;

  return 0;
}