/*************************************************************
 * A program to count the number of words in a text          *
 *************************************************************/

#include <map>
#include <string>
#include <iomanip>
#include <iostream>
using namespace std;

int main()
{
  // Declaration of map, iterator, and a string
  map <string, int > freq;
  map <string, int > :: iterator iter;
  string word;

  // Reading and storing words in the map 	
  cout << "Enter a sentence to be parsed: " << endl; 	
  while (cin >> word)
  {
    ++freq [word];
  }


  // Printing the words and their frequency	
  for (iter = freq.begin(); iter != freq.end(); iter++)
  {
    cout << left << setw(10) << iter -> first << iter -> second
    cout << endl;
  }

  return 0;
}

 	