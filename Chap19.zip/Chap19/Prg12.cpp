/**************************************************************
 * A program to check if parentheses are paired  in expression*
 **************************************************************/

#include <stack>
#include <string>
#include <iostream>
using namespace std;

int main()
{
  // Declaration of a stack, a string, and a boolean object
  stack <char> stk;
  string expr;
  bool paired = true;


  // Inputting an expression and pushing or popping it
  cout << "Enter an expression: " ;
  getline(cin, expr);
  int i = 0;
  while (i < expr.size() && paired)
  {
    char next = expr[i];
    if (next == ' (')
    {
      stk.push(next);
    }
    else if (next == ')')
    {
       if (stk.empty())
       {
         paired = false;  //If stack is empty here, no pairing
       }
       else 
       {
         stk.pop();
       }
    }
    i++;
  }


  // If stack not empty at the end, parentheses not paired 
  if (!stk.empty())
  { 
    paired = false;
  }


  // Print the result 	
  if (paired)
  {
    cout << "Parentheses are paired!" << endl;
  }
  else
  {
    cout << "Parentheses are not paired!" << endl;
  }

  return 0;
}


 