/*************************************************************
 * Using a stack to change a decimal number to hexadecimal   *
 *************************************************************/

#include <stack>
#include <iostream>
using namespace std;

int main()
{
  // Instantiation of a stack
  stack <char> stk;


  // Creation of two strings and a declaration of a variable
  string converter("0123456789ABCDEF");
  string hexadecimal;
  int decimal;


  // Inputting a decimal number
  do 
  {
    cout << "Enter a positive integer: ";
    cin >> decimal;
  } while (decimal <= 0);

  // Creation of hexadecimal characters and pushint into stack	
  while (decimal != 0)
  {
    stk.push(converter [decimal % 16]);
    decimal = decimal / 16;
  }


  // Popping characters from stack and pushing into hex string
  while (!stk.empty())
  {
    hexadecimal.push_back(stk.top(());
    stk.pop();
  }
  cout << "The hexadecimal number : " << hexadecimal;
 
  return 0;
}


