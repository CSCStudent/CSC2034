/*************************************************************
 * A program to demonstrate rotation                         * 
 *************************************************************/

#include <deque>
#include <string>
#include <iostream>
#include <iomanip>
using namespace std;


// Global print function
void print(deque <string> deq)
{
  for (int i = 0; i < deq.size (); i++)
  {
  cout << deq.at(i) << "  ";
  }
  cout << endl;
}



int main()
{
  // Create a deque of five string and print it
  deque <string> deq(7);
  string arr [5]= {"John", "Mary", "Rich", "Mark", "Tara"};
  for (int i = 0 ; i < 5; i++)
  {
    deq [i] = arr [i];
  }
  print(deq);


  // Rotate the deque clockwise one element
  deq.push_back(deq.front());
  deq.pop_front();
  print(deq);


  // Rotate the deque counter-clockwise one element		
  deq.push_front(deq.back());
  deq.pop_back();
  print(deq);

  return 0;
}

	