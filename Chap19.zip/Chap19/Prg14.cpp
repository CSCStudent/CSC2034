/**************************************************************
 * A program to test the priority_queue class                 *
 **************************************************************/

#include <queue>
#include <iostream>
using namespace std;

int main()
{
  // Create a priority_queue object
  priority_queue <int> line;

  // Push some elements
  line.push(4);
  line.push(7);
  line.push(2);
  line.push(6);
  line.push(7);
  line.push(8);
  line.push(2);

  // Print the elements according to their priorities	
  while (!line.empty ())
  {
    cout << line.top() << "    ";
    line.pop();
  }

  return 0;
}



	