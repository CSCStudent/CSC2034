/*************************************************************
 * A program that sorts a vector using sort algorithm        * 
 *************************************************************/

#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

// Definition of print function
void print(int value)
{
  cout << value << "  ";
}



int main()
{
  // Instantiation of a vector object
  vector <int> vec ;

  // Pushing six elements into the vector and print them
  vec.push_back(17);
  vec.push_back(10);
  vec.push_back(13);
  vec.push_back(18);
  vec.push_back(15);
  vec.push_back(11);
  cout << "Original vector" << endl;
  for_each(vec.begin(), vec.end(), print);
  cout << endl << endl;

 
  // Sorting the vector in ascending order and print it
  cout << "Vector after sorting in ascending order" << endl;	
  sort(vec.begin(), vec.end());
  for_each(vec.begin(), vec.end(), print);
  cout << endl << endl;

  
  // Sorting the vector in descending order and print it
  cout << "Vector after sorting in descending order" << endl;	
  sort(vec.begin(), vec.end(), greater <int>());
  for_each(vec.begin(), vec.end(), print);
  cout << endl << endl;
  
  return 0;
}

	