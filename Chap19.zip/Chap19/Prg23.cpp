/*************************************************************
 * Calling a function object to print the same value         *
 *************************************************************/

#include <iostream>
using namespace std;


class Print 
{
  public: 
  void operator()(int value) {cout << value;}
};



int main()
{
  Print print;  // Instantiation of an object of type Print
  print(45);    // calling operator()
  return 0;
}
