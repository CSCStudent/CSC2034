/*************************************************************
 * Applying a function to all elements in a range using the  *
 * algorithm for_each in the library                         *
 *************************************************************/

#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;


// Definition of the print function
void print(int value) 
{
  cout << value << "  ";
}


int main()
{
  // Instantiation of a vector object and storing three values
  vector <int> vec;
  vec.push_back(24);
  vec.push_back(42);
  vec.push_back(73);

  // Using a print function to print the value of each element
  for_each(vec.begin(), vec.end(), print);

  return 0;
}



