/**************************************************************
 *A program to create five pairs of student and score in a map*
 **************************************************************/

#include <map>
#include <iostream>
#include <iomanip>
#include <utility>
using namespace std;


int main()
{
  // Creation of a map and the corresponding iterator
  map <string, int > scores;
  map <string, int > :: iterator iter;

  // Inputting student name and score in the map
  scores ["John"] = 52;
  scores ["George"] = 71;
  scores ["Mary"] = 88;
  scores ["Lucie"] = 98;
  scores ["Robert"] = 77;

  // Printing the names and score sorted on names
  cout << "Students names and scores" << endl;
  for (iter = scores.begin (); iter != scores.end(); iter++)
  {
    cout << setw(10) << left << iter -> first << "  "; 
    cout << setw(4) << iter -> second << endl;
  } 

  return 0;
}


