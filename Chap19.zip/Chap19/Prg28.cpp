/*************************************************************
 * A program that uses binary search on a vector             * 
 *************************************************************/

#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;


int main()
{
  // Instantiation of a vector object	
  vector <int> vec ;

  // Adding six elements to the vector
  vec.push_back(17);
  vec.push_back(10);
  vec.push_back(13);
  vec.push_back(18);
  vec.push_back(15);
  vec.push_back(11);

  // Sorting the vector		
  sort(vec.begin(), vec.end());
 
  // Searching vector for two values	
  cout << "Found 10 in vector? " << boolalpha; 
  cout << binary_search(vec.begin(), vec.end(), 10) << endl;
  cout << "Found 19 in vector? " << boolalpha; 
  cout << binary_search(vec.begin(), vec.end(), 19) << endl;

  return 0;
}


	