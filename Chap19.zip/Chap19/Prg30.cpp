/**************************************************************
 * A program test numeric algorithm accumulate.               *
 **************************************************************/


#include <vector>
#include <numeric>
#include <iostream>
using namespace std;

// A print function 
void print(int value)
{
  cout << value << "  ";
}


int main()
{
  // Instantiate and print a vector
  vector <int> vec ;
  vec.push_back(17);
  vec.push_back(10);
  vec.push_back(13);
  vec.push_back(13);
  vec.push_back(18);
  vec.push_back(15);
  vec.push_back(17);
  for_each(vec.begin(), vec.end(), print);
  cout << endl;


  // Calculate the sum and print it
  int sum = accumulate(vec.begin(), vec.end(), 0);
  cout << "Sum of elements: " << sum;

  return 0;
}

	