/*************************************************************
 * A simple program to test random-access iterators in both  *
 * regular and reverse iterators                             *
 *************************************************************/

#include <iostream>
#include <vector>
using namespace std;


int main()
{
  // Instantiation of a vector and two iterators
  vector <int> vec;
  vector <int> :: iterator iter1; 
  vector <int> :: reverse_iterator iter2;

 
  // Filling the vector with 10 elements	
  for (int i = 0; i < 10; i++)
  {
    vec.push_back(i * 10);
  }


  // Using the regular iterator to print 40 followed by 20	
  cout << "Printing 40 followed by 20" << endl;
  iter1 = vec.begin();
  iter1 += 4;
  cout << *iter1 << " ";
  iter1 -= 2;
  cout << *iter1 << endl;


  // Using the reverse iterator to print 70 followed by 50	
  cout << "Printing 50 followed by 70" << endl;
  iter2 = vec.rbegin();
  iter2 += 4;
  cout << *iter2 << " ";
  iter2 -= 2;
  cout << *iter2 << endl;

  return 0;
} 


