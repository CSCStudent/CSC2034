/*************************************************************
 * Using a set to create a sorted container of integers      *
 *************************************************************/

#include <set>
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  // Create an empty set of integers
  set <int> st;


  // Insert some keys in the set	 (with duplicates)
  st.insert(47);
  st.insert(18);
  st.insert(12);
  st.insert(24);
  st.insert(52);
  st.insert(20);
  st.insert(24);
  st.insert(92);
  st.insert(53);
  st.insert(77);
  st.insert(98);
  st.insert(87);


  // Print the set elements from smallest to largest
  cout << "Printing set elements from smallest to largest.";
  cout << endl;
  set <int> :: iterator iter;
  for (iter = st.begin(); iter != st.end(); iter++)
  {
    cout << setw(4) << *iter;
  }
  cout << endl << endl;


  // Print the set elements from largest to smallest
  cout << "Printing set elements from largest to smallest.";
  cout << endl;
  set <int> :: reverse_iterator riter;
  for (riter = st.rbegin(); riter != st.rend(); riter++)
  {
    cout << setw(4) << *riter;
  }
  cout << endl << endl;


  // Print the element after 52
  set <int> :: iterator iter1 = st.find(52);
  iter1++;
  cout << "Element after 52: " << *iter1 << endl;


  // Print the element before 20
  set <int> :: iterator iter2 = st.find (20);
  iter2--;
  cout << "Element before 20: " << *iter2 << endl;

  return 0;
}

