/*************************************************************
 * The implementation file for the Student class             *
 *************************************************************/

#include "student.h"

// Constructor
Student :: Student(int id, string nm, double gp) 
: identity (id), name (nm), gpa (gp)
{
}

                                         
// Destructor
Student :: ~Student() 
{
}

  
// Print member function
void Student :: print() const
{
  cout << setw(3) << right << identity << "  " ; 
  cout << setw(12) << left << name << "  " ; 
  cout << setw(6) << right << showpoint << setprecision(3) ;
  cout << gpa << "  " << endl;
}


// Friend less-than operator
bool operator<(const Student& left, const Student& right)
{
  return (left.identity < right.identity) ;
}


