/*************************************************************
 * A program to use some mutating algorithms                 *
 *************************************************************/

#include <vector>
#include <algorithm>
#include <iostream>
#include <iomanip>
using namespace std;


// Definition of print function
void print(int value)
{
  cout << value << "  ";
}


int main()
{
  // Instantiation of a vector object	
  vector <int> vec ;

  // Adding six values
  vec.push_back(11);
  vec.push_back(14);
  vec.push_back(17);
  vec.push_back(23);
  vec.push_back(35);
  vec.push_back(52);


  // Printing original values
  cout << "Original vector" << endl;
  for_each(vec.begin(), vec.end(), print);
  cout << endl << endl;

 
  // Reversing the values and print the vector
  cout << "Vector after reversing the order" << endl;	
  reverse(vec.begin(), vec.end());
  for_each(vec.begin(), vec.end(), print);
  cout << endl << endl; 

 
  // Rotate the values and print the vector
  cout << "Vector after rotating the order" << endl;
  rotate(vec.begin(), vec.begin() + 2, vec.end());
  for_each(vec.begin(), vec.end(), print);
  cout << endl << endl; 


  // Random shuffle the value print the vector
  cout << "Vector after random shuffle" << endl;
  random_shuffle(vec.begin(), vec.end());
  for_each(vec.begin(), vec.end(), print);
  cout << endl << endl;
 
  return 0;
}




	