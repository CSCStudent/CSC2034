/**************************************************************
 * The header file defines two template functions. The first  * 
 * inserts a fundamental type into a string. The second       *
 * extracts a fundamental type embedded in a string.          *
***************************************************************/

#ifndef CONVERT_H
#define CONVERT_H
#include <iostream> 
#include <string>
#include <sstream> 
using namespace std;

// toString function changes any data type to string
template <typename T>
string toString (T data)
{
  ostringstream oss ("");
  oss << data;
  return oss.str ();
}


// toData function takes out the data embedded in a string
template <typename T>
T toData (string strg)
{
  T data; 
  istringstream iss (strg);
  iss >> data; 
  return data;
}

#endif

