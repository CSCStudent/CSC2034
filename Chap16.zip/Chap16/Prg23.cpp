/**************************************************************
 * A program to show how predefined manipulators can achieve  *
 * the same goal as using flags, fields, and variables        *
 **************************************************************/

#include <iostream>
#include <iomanip>
using namespace std; 

int main ()
{
  // Declaration and initialization of three variables
  bool b = true;
  int i = 12000;
  double d = 12467.372;

  // Printing values	
  cout << "Printing without using formatting" << endl;
  cout << "Value of b: " << b << endl;
  cout << "Value of i: " << i << endl;
  cout << "Value of d: " << d << endl << endl;

  // Formatting the boolean data and print it again		
  cout << "Formatting the Boolean data" << endl;
  cout.setf (ios :: boolalpha);
  cout << boolalpha << b << endl << endl;

  // Formatting the integer data and print it again			
  cout << "Formatting the integer data type" << endl;
  cout << showbase << uppercase << hex << right
       << setw (16) << setfill ('*') << i << endl << endl;

  // Formatting the floating-point data and print it again		
  cout << "Formatting the floating-point data type" << endl;
  cout << showpoint << right << fixed << setw (16)  
       << setprecision (2) << setfill ('*') << d  << endl
       << endl;

  return 0;
}