/**************************************************************
 * Implementation of the class length                         *
 **************************************************************/


#include "length.h"

// Definition of the length member function
length :: length (int n1)
: n (n1)
{
}

// Overloaded operator << 
ostream& operator << (ostream& stream, const length& len )
{
  stream.width (len.n);
  return stream;
}


