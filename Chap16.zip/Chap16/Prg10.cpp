/**************************************************************
 * A program that opens a file,sums its contents and writes   *
 * the sum at the end of the file                             *
 **************************************************************/

#include <iostream>
#include <fstream>
#include <cassert>
using namespace std; 

int main ()
{
  // Instantiate an fstream object	
  fstream fstr;

  // Open the intFile and connected to the fstream object
  fstr.open ("intFile", ios :: in | ios :: out);
  if (!fstr.is_open())
  {
    cout << "intFile cannot be opened!";
    assert (false);
  }

  // Read all integers and add to sum until end of file detected 
  int num;
  int sum = 0;
  while (fstr >>  num)
  {
    sum += num;	
  }

  // Clear the file and add the message and the sum to the file
  fstr.clear ();
  fstr << "\nThe sum of the numbers is: ";
  fstr << sum;

  // Close the stream	
  fstr.close ();

  return 0;	
}


