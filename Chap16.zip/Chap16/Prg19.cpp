/**************************************************************
 * A program to show how to use string stream classes         * 
 **************************************************************/

#include <iostream>
#include <string>
#include <sstream>
using namespace std; 

int main ()
{
  // Using istringstream object	
  istringstream iss ("Hello friends!");
  cout << iss.str () << endl; 
  iss.str ("Hello world!");
  cout << iss.str () << endl << endl;
 
  // Using ostringstream object	
  ostringstream oss ("Bye friends!");
  cout << oss.str () << endl; 
  oss.str ("Bye world!");
  cout << oss.str () << endl; 
  return 0;
}

