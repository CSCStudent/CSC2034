/**************************************************************
 * A program to open a file, append the current date at the   *
 * end of the file and close it                               *
 **************************************************************/

#include <iostream>
#include <fstream>
#include <cassert>
using namespace std; 

int main ()
{
  // Instantiate an ostream object
  ofstream ostr;

  // Open file1 and connect it to the ostream object
  ostr.open ("file1", ios :: out | ios :: app);
  if (!ostr.is_open())
  {
    cout << "file1 cannot be opened!";
    assert (false);
  }

  // Append the date as a C-string to file1
  ostr << "\nOctober 15, 2016.";

  // Close the file	
  ostr.close ();

  return 0;	
}

