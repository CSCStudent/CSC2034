/**************************************************************
 * A program to open a file, read its contents character by   *
 * by character and write each character on another file      *
 **************************************************************/

#include <iostream>
#include <fstream>
#include <cassert>
using namespace std; 

int main ()
{
  // Variable declaration
  char ch;

  // Instantiation of an ifstream and an ofstream object	
  ifstream istr;
  ofstream ostr;

  // Opening file1 and file2 and testing if they are open
  istr.open ("file1", ios :: in);
  if (!istr.is_open())
  {
    cout << "file1 cannot be opened!" << endl;
    assert (false);
  }
  ostr.open ("file2", ios :: out);
  if (!ostr.is_open())
  {
    cout << "file2 cannot be opened!" << endl;
    assert (false);
  }

  // Reading file1 character by character and writing to file2
  while (istr.get (ch))
  {
    ostr.put(ch);
  }

  // Closing file1 and file2
  istr.close ();
  ostr.close ();

  return 0;	
}

