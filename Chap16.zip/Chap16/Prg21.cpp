/**************************************************************
 * A simple application program that uses toString and toData * 
 * template functions                                         *
 **************************************************************/

#include "convert.h"

int main ( )
{
  // Converting integer 12 to a string
  string strg = toString (12);
  cout << "String: " << strg << endl;

  // Converting string "15.67" to double	
  double data = toData <double> ("15.67");
  cout << "Data: " << data;
  return 0;
}

 