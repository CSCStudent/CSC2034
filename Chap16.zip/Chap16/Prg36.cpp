/*************************************************************
 * The application file for RSA at the encryption site       *
 *************************************************************/

#include "rsa.h"

int main ()
{
  RSA rsa (13, 77);   // 13 is e and 77 is n
  rsa.crypt ("plainFile", "cipherFile");
  return 0;
}


	