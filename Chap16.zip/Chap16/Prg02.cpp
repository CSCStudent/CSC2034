/*************************************************************
 * A program to read characters and print their ASCII values *
 *************************************************************/

#include <iostream>
using namespace std; 

int main ()
{
  int x; 
  cout << "Enter five characters (no spaces): "; 
  for (int i = 0; i < 5; i++)
  {
    x = cin.get ();
    cout << x << "  ";
  }
  return 0;
}


