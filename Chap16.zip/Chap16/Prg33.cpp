/*************************************************************
 * The application file used to decrypt the message          *
 *************************************************************/

#include "monoalpha.h"

int main ( )
{
  MonoAlpha monoalpha;
  monoalpha.decrypt ("cipherFile", "plainFile");
  return 0;
}	 						

