/**************************************************************
 * A program that extracts only integers from an input file   *
 * that contains both integer and character data types        *
 **************************************************************/

#include <iostream>
#include <fstream>
#include <cassert>
using namespace std; 

int main ()
{
  // Instantiation of ifstream object and connection to file
  ifstream ifstr;
  ifstr.open ("mixedFile" , ios :: in);
  if (!ifstr.is_open())
  {
    cout << "The file mixedFile cannot be opened for reading!";
    assert (false);
  }

  // Reading only integers by putting back non-digits 
  char ch;
  int n;
  while (ifstr.get (ch))
  {
    if (ch >= '0' && ch <= '9')
    {
      ifstr.unget();
      ifstr >> n;
     cout << n << " ";
    }
  }

  // Closing the file
  ifstr.close ();

  return 0;
}


