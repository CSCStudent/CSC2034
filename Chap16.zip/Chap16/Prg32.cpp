/*************************************************************
 * The application file used to encrypt the message          *
 *************************************************************/


#include "monoalpha.h"

int main ()
{
  MonoAlpha monoalpha;
  monoalpha.encrypt ("plainFile", "cipherFile");
  return 0;
}

						