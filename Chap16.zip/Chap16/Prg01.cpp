/*************************************************************
 * A program to show how to test the state of a stream       *
 *************************************************************/

#include <iostream>
using namespace std; 

int main ()
{
  int n;				
  cout << "Enter a line of integers and eof at the end: ";
  cout << endl; 
  while (cin >> n)
  {
    cout << n * 2 << " ";
  }
  return 0;
}

