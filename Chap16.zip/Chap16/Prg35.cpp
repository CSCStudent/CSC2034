/*************************************************************
 * The implementation file for RSA asymmetric-key cipher     *
 *************************************************************/

#include "rsa.h"
#include <fstream>
#include <cmath>


// Constructor
RSA :: RSA (int k, int m)
: key (k), modulus (m)
{
}

// Destructor
RSA :: ~RSA ()
{
}


// Encryption and decryption function
void RSA :: crypt (const char* inFile, const char* outFile)
{
  ifstream  istrm (inFile, ios :: in);
  ofstream  ostrm (outFile, ios :: out);
  int base, result;
  while (istrm >> base)
  {
    result = modulo (base, key, modulus);
    ostrm << result;
   ostrm << ' ';
  }
  istrm.close ();
  ostrm.close ();
}


// Modulo calculation
int RSA :: modulo (int base, int power, int modulus)
{
  int result = 1;
  for (int i = 0; i < power; i++)
  {
    result = (result * base) % modulus;
  }
  return result; 
}



