/*************************************************************
 * The application file for RSA at the decryption site       *
 *************************************************************/

#include "rsa.h"

int main ()
{
  RSA rsa (37, 77);  //37 is d and 77 is n
  rsa.crypt ("cipherFile", "plainFile");
  return 0;
}

	