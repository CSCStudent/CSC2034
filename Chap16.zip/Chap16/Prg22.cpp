/**************************************************************
 * A program to show how to format three data types using the *
 * formatting flags, fields and variables.                    *
 **************************************************************/

#include <iostream>
using namespace std; 

int main ()
{
  // Declaration and initialization of three variables
  bool b = true;
  int i = 12000;
  double d = 12467.372;

  // Printing values
  cout << "Printing without using formatting" << endl;
  cout << "Value of b: " << b << endl;
  cout << "Value of i: " << i << endl;
  cout << "Value of d: " << d << endl << endl;

  // Formatting the Boolean data and print it again	
  cout << "Formatting the Boolean data" << endl;
  cout.setf (ios :: boolalpha);
  cout << b << endl << endl;

  // Formatting the integer data and print it again		
  cout << "Formatting the integer data type" << endl;
  cout.setf (ios :: showbase);
  cout.setf (ios :: uppercase);
  cout.setf (ios :: hex, ios :: basefield);
  cout.setf (ios :: right, ios :: adjustfield); 
  cout.width (16);
  cout.fill ('*');
  cout << i << endl << endl;

  // Formatting the floating-point data and print it again	
  cout << "Formatting the floating-point data type" << endl;
  cout.setf (ios :: showpoint);
  cout.setf (ios :: right, ios :: adjustfield); 
  cout.setf (ios :: fixed, ios :: floatfield);
  cout.width (16);
  cout.precision (2);
  cout.fill ('*');
  cout << d << endl;
  return 0;
}


