/*************************************************************
 * The interface file for RSA asymmetric-key cipher          *
 *************************************************************/

#ifndef RSA_H
#define RSA_H
#include <iostream>
using namespace std;

class RSA
{
  private:
    int key;
    int modulus;
    int modulo (int base, int power, int modulus);
  public: 
   RSA (int key, int modulus);
   ~RSA ();
   void crypt (const char* inFile, const char* outFile);
};

#endif

