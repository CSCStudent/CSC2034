/**************************************************************
 * A program to find the length of the file                   *
 **************************************************************/

#include <iostream>
#include <fstream> 
using namespace std; 

int main ()
{
  // Instantiation of stream and connection to the file
  ifstream ifstr;
  ifstr.open ("file4" , ios :: in | ios :: ate);

  // Finding the marker value after the last character	
  cout << "File size: " << ifstr.tellg ();

  // Closing the file	
  ifstr.close ();

  return 0; 
}


