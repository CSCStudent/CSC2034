/**************************************************************
 *A program to simulate boolalpha and noboolalpha manipulators*
 **************************************************************/

#include <iostream>
using namespace std;

// Defining a function named alpha
ostream&  alpha (ostream&  os)
{
  os.setf (ios :: boolalpha) ; 
  return os;
}


// Defining a function named noalpha
ostream&  noalpha (ostream&  os)
{
  os.unsetf (ios :: boolalpha) ; 
  return os;
}


int main ()
{
  // Declaration and initialization of two boolean variables
  bool b1 = false;
  bool b2 = true;

  // Printing values of variables with defined manipulators
  cout << alpha << b1 << "   "  << b2 << endl;
  cout << noalpha << b1 << "   "  << b2 << endl;
  return 0;
}

