/**************************************************************
 * An application program to use the manipulator length(n)    *
 **************************************************************/

#include "length.h"

int main ()
{
  cout << length (10) << 123 << endl;
  cout << length (20) << 234 << endl;
  return 0;
} 