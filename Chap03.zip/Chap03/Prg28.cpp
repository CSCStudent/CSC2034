/* ************************************************************
 * This program shows how to extract the integral part and the*
 * fractional part of a floating-point number                 *
 **************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main ( )
{
  // Variable Declaration 
  double number;
  int intPart;
  double fractPart;

  // Input
  cout << "Enter a floating-point number: ";
  cin >> number;
 
  // Processing	
  intPart = static_cast <int> (number); 
  fractPart = number - intPart;

  // Output
  cout << fixed << showpoint << setprecision (2);	
  cout << "The original number: " << number << endl;	
  cout << "The integral part: " << intPart << endl;
  cout << "The fractional part: " << fractPart;
  return 0;
} 


