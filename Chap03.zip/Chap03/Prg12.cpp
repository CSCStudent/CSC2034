/************************************************************** 
 *Evaluating a simple expression with two levels of precedence*
 **************************************************************/

#include <iostream>
using namespace std;

int main ( )
{
  cout << "Result of expression: " << 5 + 7 * 4 << endl;
  return 0;      
}

 