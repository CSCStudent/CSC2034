/*************************************************************** 
 * The program shows some literal expressions.                 *
***************************************************************/

#include <iostream>
using namespace std;

int main ()
{
  cout << false << "  " << 'A' << "  " << "Hello" << endl;               
  cout << 23412 << "  " << 12897234L << endl; 
  cout << 245.78F << "   " << 114.782 << "  " << 2.051L;
  return 0;
} 
