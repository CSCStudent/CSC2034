/************************************************************ 
 * Evaluating simple expression including parentheses       *
 ************************************************************/

#include <iostream>
using namespace std;

int main ( )
{
  // Declaration 
  int x = 5;

  // Outputting value of expression
  cout << "Value of (x + 6) * 7: " << (x + 6) * 7 ; 	
  return 0;      
} 

