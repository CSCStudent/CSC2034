/************************************************************** 
 * A program to print data in different bases (decimal,octal, *
 * and hexadecimal)                                           *
 **************************************************************/

#include <iostream>
using namespace std;

int main ( )
{
  // Declaration of variable x
  int x = 1237;

  // Outputting x in three bases without showbase
  cout << "x in decimal: " << x << endl;
  cout << "x in octal: " << oct << x << endl;
  cout << "x in hexadecimal: "  << hex << x << endl << endl;

  // Outputting x in three bases with showbase
  cout << "x in decimal: " << x << endl;
  cout << "x in octal: "  << showbase << oct << x << endl;
  cout << "x in hexadecimal: "  << showbase << hex << x;
  return 0;      
}

 