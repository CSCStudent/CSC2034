/************************************************************* 
 * Evaluating an expression with three levels of precedence  *
 *************************************************************/

#include <iostream>
using namespace std;

int main ( )
{
  // Declare one variable 
  int result;

  // Evaluate expression and store the result in a variable	
  result = 5 - 15 % 4;

  // Output the result stored in the variable
  cout << "The value stored in result: " << result; 	
  return 0;      
} 


