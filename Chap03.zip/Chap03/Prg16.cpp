/************************************************************ 
 * Evaluation involving both precedence and associativity   *
 ************************************************************/

#include <iostream>
using namespace std;

int main ( )
{
  cout << "Value of expression: " << 5 - 30 / 4 * 8 + 10 ;
  return 0;      
} 
