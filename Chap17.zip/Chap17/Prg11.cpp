/*************************************************************
 * A program to create all permutations of a given string    *
 *************************************************************/
 
#include <iostream>
#include <string>
using namespace std;



// Function declarations
void permute (string);
void permute (string, string);
void swap (char&, char&);

int main ()
{
  // Permuting the string "xy"
  cout << "Permutation of xy: "; 
  permute ("xy");
  cout << endl;

  // Permuting the string "abc"
  cout << "Permutation of abc: ";
  permute ("abc");
  cout << endl;
  return 0;
}





// Definition of non-recursive permute function
void permute (string s)
{
  permute (s, "");
}




	
// Definition of recursive (helper) permute function
void permute (string str, string p)
{
  if (str.length () == 0)
  {
    cout << p << " " ;
  }
  else
  {
    for (int i = 0; i < str.length (); i++)
    {
      swap (str[0], str[i]);
      permute (str.substr (1, str.length() - 1), 
               p + str.substr (0, 1)) ;
    }
  }
}



// Definition of swap function
void swap (char& c1, char& c2)
{
  char temp = c1;
  c1 = c2;
  c2 = temp;
}


