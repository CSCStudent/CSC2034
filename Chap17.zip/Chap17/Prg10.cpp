/*************************************************************
 * A program to solve the problem of Tower of Honoi          *
 *************************************************************/ 

#include <iostream>
using namespace std;

// Function declaration
void towers (int, char, char, char);
void moveOneDisk (char, char);


int  main ()
{
  // Variable declaration
  int n;

  // Input
  do 
  {
    cout << "Enter number of disks (1 to 4): ";
    cin >> n;
  } while ((n < 1) || (n > 4));

  // Function call
  towers (n, 'A', 'C', 'B');
}



// Definition for towers function
void towers (int num, char source, char dest, char aux)
{
  if (num == 1)
  {
    moveOneDisk (source, dest);
  }
  else
  {
    towers (num - 1, source, aux, dest);
    moveOneDisk (source, dest);
    towers (num - 1, aux, dest, source);
 } 
}



// Definition for moveOneDisk function
void moveOneDisk (char start, char end)
{
  cout << "Move top disk from "; 
  cout << start << " to " << end << endl;
}



