/**************************************************************
 * The interface file of customized exception class inherited *
 * from invalid_argument class                                *
 **************************************************************/

#ifndef TRIANGLEERROR_H
#define TRIANGLEERROR_H
#include <stdexcept>
#include <iostream>
#include <string>
using namespace std;

// Class definition for TriangleError class
class TriangleError : public invalid_argument
{
  private:
    int errorType;
  public:
    TriangleError (int errorType);
    string message ();
};

#endif