/**************************************************************
 * The implementation file for SP class                       *
 **************************************************************/

#include "sp.h"

// Constructor
SP :: SP (int* p)
: ptr (p)
{
}


// Destructor
SP :: ~SP ()
{
  delete ptr;
}

 
// Overloading of the * operator
int& SP :: operator* ( ) const
{
  return *ptr;
}


// Overloading of the -> operator
int* SP :: operator-> ( ) const
{
  return ptr;
}


