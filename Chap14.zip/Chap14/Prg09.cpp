/**************************************************************
 * The interface file for the Integer class                   *
 **************************************************************/

#ifndef INTEGER_H
#define INTEGER_H
#include "sp.h"

// Definition of the Integer class
class Integer
{
  private: 
    SP sp;
  public:
    Integer (int value);
    ~Integer (); 
    int getValue();
};

#endif
