/**************************************************************
 * The implementation file for the Integer class              *
 **************************************************************/

#include "integer.h"

// Constructor using function-try block
Integer :: Integer (int v)
try: sp (new int)  
{
  *sp = v;
}
catch (...)
{
  throw;
}

// Destructor 
Integer :: ~Integer ()
{
}
 
// Accessor function
int Integer :: getValue()
{
  return *sp;
}

