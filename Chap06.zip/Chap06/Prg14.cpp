/**************************************************************
* This program shows how a change in the parameter can change * * the corresponding argument when data is passed by reference.*
***************************************************************/

#include <iostream>
using namespace std;

// Function declaration;
void fun (int&  y); // The ampersand shows y as a reference

int main ()
{
  // Declaration and initialization of an argument
  int x = 10;

  // Calling function fun and passing x as an argument
  fun (x); 
  
  // Printing the value of x to see change
  cout << "Value of x in main: " << x << endl;
  return 0;
}


/**************************************************************
 * Fun is a function that receives the value of y by reference*
 * which means the parameter y is an alias for the argument   *
 * function call. This function increments its parameters and *
 * results in incrementing the argument in main.              * 
 **************************************************************/

void fun (int&  y)
{
  y++;
  cout << "Value of y in fun: " << y << endl;
  return;
}

