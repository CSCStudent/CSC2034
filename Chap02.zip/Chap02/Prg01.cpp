int main ()

{

 std :: cout << "This is a simple program in C++ ";

 std :: cout << "to show the main structure." << std :: endl;

 std :: cout << "We learn more about the language "; 

 std :: cout << "in this chapter and the rest of the book.";

 return 0;

}
