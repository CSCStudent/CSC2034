/**************************************************************
 * This program shows how we can print a square of asterisks. *   
 **************************************************************/

#include <iostream>
using namespace std;

int main ()
{
  // Printing a square of asterisks
	cout << "******" << endl;
	cout << "******" << endl;
	cout << "******" << endl;
	cout << "******" << endl;
	cout << "******" << endl;
	cout << "******";
	return 0;
}

