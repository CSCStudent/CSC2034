/*************************************************************
 * A program to find the size of all three integer types     *
 *************************************************************/

#include <iostream>
using namespace std;

int main ()
{
  cout << "Size of short int is " << sizeof (short int);
  cout << bytes." << endl;

  cout << "Size of int is " << sizeof (int); 
  cout << " bytes." << endl;

  cout << "Size of long int is " << sizeof (long int); 
  cout << " bytes." << endl;
  return 0;
}


